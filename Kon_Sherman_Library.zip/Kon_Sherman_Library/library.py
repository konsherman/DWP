# Konner Sherman
#DWP
#Nov 4, 2014


class Library(object):
    def __init__(self):
        pass

    def calc_info(self,w1,w2,w3,w4):
        answer = w1 + w2 + w3 + w4 / 4
        return answer



class Printer(object):
    def __init__(self):
        pass

    def printstuff(self, a, b):
        print a + " " + str(b)










